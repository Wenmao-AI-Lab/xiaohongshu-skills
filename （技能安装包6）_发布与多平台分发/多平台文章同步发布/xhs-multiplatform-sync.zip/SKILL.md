---
name: xhs-multiplatform-sync
description: "多平台文章同步与分发技能。把 Markdown / HTML 文章一键同步到知乎、掘金、CSDN、头条、微博、小红书、B 站、微信公众号等 29+ 平台；数据全部本地流转，仅通过本机 localhost 与浏览器扩展通信，不经过第三方服务器。"
metadata:
  智能体:
    requires:
      env:
        - WECHATSYNC_TOKEN
      bins:
        - wechatsync
    primaryEnv: WECHATSYNC_TOKEN
    emoji: "\U0001F4DD"
    homepage: https://github.com/wechatsync/Wechatsync
    install:
      - kind: node
        package: "@wechatsync/cli"
        bins: [wechatsync]
displayName: 多平台文章同步发布
version: 1.0.0
---

# WechatSync

Publish and sync Markdown/HTML articles to 29+ content platforms via CLI.

## Prerequisites

This skill requires external tools that the user must install themselves:

1. **CLI tool** (`@wechatsync/cli`): Open-source npm package ([source code](https://github.com/wechatsync/Wechatsync/tree/v2/packages/cli)). Install with `npm install -g @wechatsync/cli`
2. **Chrome extension**: Open-source browser extension ([source code](https://github.com/wechatsync/Wechatsync/tree/v2/packages/extension)). Install from [Chrome Web Store](https://chrome.google.com/webstore/detail/hchobocdmclopcbnibdnoafilagadion) or [download ZIP](https://www.wechatsync.com/#install)
3. **Token**: User-generated token set in extension settings. The token is created locally by the user and used only for localhost communication between CLI and extension. Set via `export WECHATSYNC_TOKEN="your-token"`
4. **Platform logins**: Log in to target platforms in browser (extension uses existing browser cookies, no credentials are stored or transmitted)

**Security model**: All data stays local. The CLI communicates with the Chrome extension over localhost. The extension calls platform APIs directly from the browser using existing login sessions. No third-party server involved. Full source code is open and auditable.

Before running any command, confirm the user has completed the prerequisites. Do not install packages on the user's behalf without explicit consent.

## Commands

### Sync

```bash
wechatsync sync article.md -p juejin              # single platform
wechatsync sync article.md -p juejin,zhihu,csdn   # multiple platforms
wechatsync sync article.md -p juejin -t "Title"   # custom title
wechatsync sync article.md -p juejin --cover ./cover.png  # cover image
wechatsync sync article.md -p juejin --dry-run     # preview only
```

### Platforms & Auth

```bash
wechatsync platforms          # list all platforms
wechatsync platforms --auth   # show login status
wechatsync auth zhihu         # check single platform
```

### Extract

```bash
wechatsync extract              # extract from current browser page
wechatsync extract -o article.md  # save to file
```

## Platform IDs

zhihu, juejin, csdn, jianshu, toutiao, douyin, weibo, bilibili, xiaohongshu, baijiahao, weixin, yuque, douban, sohu, xueqiu, woshipm, dayu, yidian, 51cto, sohufocus, imooc, oschina, segmentfault, cnblogs, x, eastmoney, smzdm, netease, wordpress, typecho

## Notes

- Images auto-uploaded to target platform CDN (PNG, JPG, GIF, WebP, SVG)
- Markdown title extracted from front matter `title` or first `# heading`
- Articles sync as **drafts** by default — user reviews before publishing

## Workflow

1. Confirm prerequisites are installed (ask user if unsure)
2. Check login: `wechatsync platforms --auth`
3. Sync: `wechatsync sync <file> -p <platform1>,<platform2>`
4. Report results with draft URLs

Example prompts:
- "Sync this article to Juejin and Zhihu"
- "Which platforms am I logged into?"
- "Extract the article from browser and save it"
- "把这篇文章同步到掘金和知乎"

---

> **本技能包由「淘宝店：AI灵匣」整理优化** —— 全套 AI 工作流技能包供应商
