import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILL = (ROOT / "SKILL.md").read_text(encoding="utf-8")
ALL_MD = "\n".join(path.read_text(encoding="utf-8") for path in ROOT.rglob("*.md"))


class SkillContractTests(unittest.TestCase):
    def test_seven_platforms_present(self):
        for name in ("抖音", "小红书", "视频号", "快手", "B站", "微博", "知乎"):
            self.assertIn(name, SKILL)

    def test_exact_two_quick_conclusions_present(self):
        self.assertIn("审核没问题，可以直接发。", SKILL)
        self.assertIn("不建议直接发。", SKILL)

    def test_six_way_short_video_labels_present(self):
        for label in (
            "含有虚构演绎内容",
            "含有AI生成内容",
            "含有营销信息",
            "内容为转载",
            "内容为个人观点",
            "无需标注",
        ):
            self.assertIn(label, ALL_MD)

    def test_no_alias_pass_guarantee(self):
        for phrase in ("别名即可过审", "某音可以过审", "橙色软件可以过审", "只说一次就能过审"):
            self.assertNotIn(phrase, ALL_MD)

    def test_local_markdown_links_resolve(self):
        for path in (ROOT / "SKILL.md", *ROOT.joinpath("references").glob("*.md")):
            text = path.read_text(encoding="utf-8")
            for target in re.findall(r"\[[^\]]+\]\(([^)]+\.md)\)", text):
                with self.subTest(source=path.name, target=target):
                    self.assertTrue((path.parent / target).resolve().exists())

    def test_platform_files_exist(self):
        expected = [
            "platform-douyin.md",
            "platform-xiaohongshu.md",
            "platform-weixin-video-accounts.md",
            "platform-kuaishou.md",
            "platform-bilibili.md",
            "platform-weibo.md",
            "platform-zhihu.md",
        ]
        for filename in expected:
            with self.subTest(filename=filename):
                self.assertTrue((ROOT / "references" / filename).exists())


if __name__ == "__main__":
    unittest.main()
