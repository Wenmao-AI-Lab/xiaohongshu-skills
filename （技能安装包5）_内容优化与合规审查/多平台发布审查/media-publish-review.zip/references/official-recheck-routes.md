# 官方复查入口

核验日期：2026-07-18。平台页面、菜单名称和登录路径会更新；网页打不开时优先使用对应 App 内的创作者中心、规则中心、发布页提示和账号通知。

## 使用原则

- 只推荐与当前风险有关的 1–3 个入口，不输出一整页无关链接；
- 区分"规则查询""账号/作品检测""事实/资质核验""申诉"；
- 用户说"打开官方复查"或"继续深查"时，有浏览器能力就打开对应官方页面；
- 不把第三方违禁词检测、收录查询或课程网站称为官方审核。

## 抖音

- [抖音创作者中心](https://creator.douyin.com/)
- [抖音规则中心](https://www.douyin.com/rule/main)
- [抖音安全与信任中心](https://95152.douyin.com/)
- [抖音用户服务协议](https://www.douyin.com/agreements/?id=6773906068725565448)

## 小红书

- [小红书创作服务平台](https://creator.xiaohongshu.com/login?source=official)
- [小红书电商学习中心](https://school.xiaohongshu.com/)

## 微信视频号

- [视频号助手](https://channels.weixin.qq.com/)
- 微信 App 内：发现 → 视频号 → 个人中心/创作者中心

## 快手

- [快手社区规则](https://www.kuaishou.com/norm?tab=community)
- [快手创作者服务平台](https://cp.kuaishou.com/)
- [快手帮助中心](https://www.kuaishou.com/help/feedback/4033?categoryId=hot)

## B站

- [哔哩哔哩创作中心](https://member.bilibili.com/)
- [哔哩哔哩社区规范](https://www.bilibili.com/blackboard/community-rules.html)
- [哔哩哔哩帮助中心](https://www.bilibili.com/blackboard/help.html)

## 微博

- [微博管理中心](https://service.account.weibo.com/)
- [微博社区公约](https://service.account.weibo.com/roles/gongyue)
- [微博帮助中心](https://kefu.weibo.com/)

## 知乎

- [知乎创作者中心](https://www.zhihu.com/creator)
- [知乎社区管理规定](https://www.zhihu.com/question/19551824)
- [知乎帮助中心](https://www.zhihu.com/help)

## 官方事实核验

- 辟谣：[中国互联网联合辟谣平台](https://www.piyao.org.cn/)
- 企业信息：[国家企业信用信息公示系统](https://www.gsxt.gov.cn/)
- 药品/化妆品：[国家药品监督管理局](https://www.nmpa.gov.cn/zwfwqjd/index.html)
- 商标：[国家知识产权局商标查询](https://sbj.cnipa.gov.cn/sbj/sbcx/)
- 广告执法：[市场监管总局广告监管](https://www.samr.gov.cn/ggjgs/)
- 法律条文：[国家法律法规数据库](https://flk.npc.gov.cn/)

## 输出"官方复查卡"

```markdown
### 官方复查卡
- 为什么要复查：[当前具体风险]
- 先打开：[官方入口]
- 在哪里查：[网页栏目或 App 内关键词]
- 准备材料：[来源/授权/资质/截图/处罚通知]
- 复查后告诉我：[需要用户带回的结果]
```
