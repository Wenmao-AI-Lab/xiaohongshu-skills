#!/usr/bin/env python3
"""营销文案生成器 - 提示词组装器

把用户输入（主题/产品、目标平台、可选卖点、版本数）组装成结构化提示词，
交给 AI助手 原生生成能力产出分版本文案。纯本地文本编排，无外部调用。

用法：
    python build_prompt.py --platform xiaohongshu --topic "便携咖啡机" --selling "出差也能喝现磨" --versions 5
    python build_prompt.py --platform all --topic "护肤精华" --versions 3
    python build_prompt.py --platform xiaohongshu --topic "便携咖啡机" --humanize

平台枚举：xiaohongshu / douyin / ecommerce / wechat / moments / all
开关：--humanize 开启去 AI 味（调用 humanizer 模式，按平台保留原生表达）
"""
import argparse
import sys

# 平台调性库（与 references/platform-tone-guide.md 保持一致）
PLATFORM_TONE = {
    "xiaohongshu": "小红书：口语化、像真实用户分享，多用emoji与短句，前置痛点共鸣，弱化广告感，结尾可加话题标签",
    "douyin": "抖音：强节奏口播，前3秒抓注意力，口语化且有情绪张力，适合测评/种草口吻，配动作提示",
    "ecommerce": "电商：转化导向，标题含核心关键词与卖点，详情页结构化（痛点-方案-卖点-证据-促单），直接促单",
    "wechat": "公众号：深度长文调性，逻辑清晰、有观点有故事，标题抓人但不标题党，适合种草+测评结合",
    "moments": "朋友圈：轻社交、像朋友安利，短小自然，不硬广，可用生活化场景带出产品",
}
PLATFORM_LABEL = {
    "xiaohongshu": "小红书", "douyin": "抖音", "ecommerce": "电商",
    "wechat": "公众号", "moments": "朋友圈",
}

VERSIONS_LABEL = ["种草版", "硬广版", "测评版", "对比版", "场景故事版"]

COMPLIANCE = (
    "合规约束：不使用'最/第一/国家级/绝无仅有'等绝对化用语；不编造功效、不夸大效果、"
    "不做无资质医疗/保健宣称；不生成虚假用户评价或伪造销量数据。"
)

# 去 AI 味指令（humanizer 模式）。按平台差异化：小红书/抖音/朋友圈保留原生 emoji 与口语，
# 只剥 AI 痕迹（促销腔、规则三段、虚浮结论、em dash 滥用、虚词堆叠）；电商/公众号侧重删修饰词。
HUMANIZE = (
    "去 AI 味（humanizer 模式）：让文案像真人随手写的，不要像机器生成。具体要求：\n"
    "1. 删掉促销腔与虚浮词：boasts/showcasing/groundbreaking/vibrant/profound 这类堆砌词不用；"
    "不用'不仅是…更是…''不是…而是…'这类排比；不强行凑三点。\n"
    "2. 句子长短交替，有真实语气和一点个人看法，允许短句、口语、甚至半句闲笔，别太规整。\n"
    "3. 不用长破折号(——)连缀句子；少用过度加粗；结论要具体，不要空泛升华。\n"
    "4. 平台差异化：小红书/抖音/朋友圈可保留适量 emoji 与口语化表达（这是平台原生调性，不算 AI 痕迹），"
    "但不要每句都堆 emoji；电商/公众号则尽量用简单陈述句，去掉夸张修饰。"
)


def build_prompt(platform: str, topic: str, selling: str, versions: int, humanize: bool = False) -> str:
    if platform == "all":
        targets = list(PLATFORM_TONE.keys())
    else:
        targets = [platform]

    blocks = []
    for t in targets:
        label = PLATFORM_LABEL.get(t, t)
        tone = PLATFORM_TONE.get(t, "")
        n = max(1, min(versions, 5))
        vers = "、".join(VERSIONS_LABEL[:n])
        blocks.append(
            f"【{label}】调性：{tone}\n"
            f"请生成 {n} 个版本（{vers}），每个版本标注适用场景与配图/话题建议。"
        )

    selling_line = f"\n核心卖点参考：{selling}" if selling else ""
    humanize_block = f"\n\n{HUMANIZE}\n" if humanize else ""
    prompt = (
        f"你是一名资深营销文案。请为下面的产品/服务撰写营销文案。\n\n"
        f"推广主题：{topic}{selling_line}\n\n"
        f"按以下平台分别适配调性并生成：\n"
        + "\n".join(blocks)
        + f"\n\n{COMPLIANCE}\n"
        f"每条文案尾部附一句合规提示。整体避免空话，结合卖点给出具体可感知的描述。"
        + humanize_block
    )
    return prompt


def main():
    ap = argparse.ArgumentParser(description="营销文案生成器 - 提示词组装")
    ap.add_argument("--platform", default="xiaohongshu",
                    choices=list(PLATFORM_TONE.keys()) + ["all"])
    ap.add_argument("--topic", required=True, help="推广的产品/服务主题")
    ap.add_argument("--selling", default="", help="可选：核心卖点参考")
    ap.add_argument("--versions", type=int, default=3, help="每个平台生成的版本数(1-5)")
    ap.add_argument("--humanize", action="store_true",
                    help="开启去 AI 味（humanizer 模式），按平台保留原生表达")
    args = ap.parse_args()

    try:
        prompt = build_prompt(args.platform, args.topic, args.selling, args.versions, args.humanize)
    except Exception as e:  # noqa
        print(f"组装失败：{e}", file=sys.stderr)
        sys.exit(1)
    print(prompt)


if __name__ == "__main__":
    main()
