#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
种草笔记标题生成器
- 根据主题/内容摘要生成多个标题候选
- 内置 15+ 种标题公式
- 标题评分 + 限流词检测
"""

import sys
import argparse
import re
import random

# ============================================================
# 15+ 种标题公式模板
# 每个公式包含：名称、模板列表（{topic}会被替换为主题）、说明
# ============================================================
TITLE_FORMULAS = [
    {
        "name": "数字型",
        "description": "用具体数字增加可信度和点击欲",
        "templates": [
            "{n}个方法让你{topic}再也不踩坑",
            "学会这{n}招，{topic}直接开挂",
            "{topic}的{n}个真相，第{n2}个你一定不知道",
            "保姆级{topic}攻略｜{n}步搞定",
        ],
        "need_numbers": True,
    },
    {
        "name": "反差型",
        "description": "制造认知反差，激发好奇心",
        "templates": [
            "月薪3000 vs 月薪3万的{topic}区别，看完沉默了",
            "以前{topic}vs 现在{topic}，差别居然这么大",
            "普通人{topic} VS 大佬{topic}，差的不是钱是认知",
            "{topic}前我以为…{topic}后我才知道…",
        ],
        "need_numbers": False,
    },
    {
        "name": "悬念型",
        "description": "留悬念勾引读者点进来",
        "templates": [
            "原来{topic}一直都用错了！99%的人都不知道",
            "{topic}的终极秘密，没人敢说的大实话",
            "千万别{topic}！除非你看过这篇",
            "我敢打赌，90%的人都不知道{topic}的真相",
        ],
        "need_numbers": False,
    },
    {
        "name": "痛点型",
        "description": "精准戳中痛点，引发共鸣",
        "templates": [
            "{topic}总是失败？因为你忽略了这一点",
            "为什么你{topic}总是没效果？真相扎心了",
            "被{topic}困扰了3年，终于找到解决方案了",
            "{topic}踩过的坑比路还多？这篇帮你全避开",
        ],
        "need_numbers": False,
    },
    {
        "name": "身份认同型",
        "description": "锁定目标人群，精准触达",
        "templates": [
            "30岁女生必看的{topic}秘籍",
            "打工人{topic}指南｜性价比拉满",
            "学生党{topic}合集｜平价又好用",
            "宝妈必入！{topic}神器，省心十倍",
        ],
        "need_numbers": False,
    },
    {
        "name": "清单型",
        "description": "合集/清单，收藏欲拉满",
        "templates": [
            "{topic}合集｜全是好物，建议收藏",
            "私藏{n}款{topic}推荐，每一个都绝了",
            "{topic}红黑榜｜这些千万别买",
            "年度{topic}大赏｜我的TOP{n}分享",
        ],
        "need_numbers": True,
    },
    {
        "name": "教程型",
        "description": "手把手教，实用价值高",
        "templates": [
            "手把手教你{topic}，小白也能学会",
            "{topic}零基础入门，看这一篇就够了",
            "超详细{topic}教程｜一步一步跟着做",
            "{topic}保姆级教程｜从0到1全攻略",
        ],
        "need_numbers": False,
    },
    {
        "name": "对比型",
        "description": "二选一/多选一，选择困难症最爱",
        "templates": [
            "{topic}A和{topic}B到底选哪个？一篇讲透",
            "热门{topic}大PK，谁才是性价比之王",
            "贵价vs平价{topic}，差别真的很大吗",
            "{topic}选前必看！热门款全方位对比",
        ],
        "need_numbers": False,
    },
    {
        "name": "故事型",
        "description": "用故事钩子吸引人",
        "templates": [
            "我妈用了都说好的{topic}，必须安利给你们",
            "被闺蜜种草的{topic}，真香了",
            "用了{n}年的{topic}，真心推荐不踩雷",
            "踩了无数坑后，终于找到了完美的{topic}",
        ],
        "need_numbers": True,
    },
    {
        "name": "利益承诺型",
        "description": "直接说好处，给读者行动理由",
        "templates": [
            "这样{topic}，效率翻{n}倍",
            "{topic}小技巧，帮你省下一大笔钱",
            "学会这个{topic}方法，省时又省力",
            "{topic}的正确姿势，学会就是赚到",
        ],
        "need_numbers": True,
    },
    {
        "name": "反常识型",
        "description": "打破固有认知，制造惊讶",
        "templates": [
            "{topic}竟然是错的？！我们被骗了这么多年",
            "别再{topic}了！专家说这样才对",
            "颠覆认知！{topic}的真相居然是这样",
            "你以为的{topic}，其实全错了",
        ],
        "need_numbers": False,
    },
    {
        "name": "时间紧迫型",
        "description": "制造稀缺感和紧迫感",
        "templates": [
            "赶紧码住！{topic}攻略随时删",
            "{topic}限时分享，看到就是赚到",
            "趁还没人发现，赶紧收藏这篇{topic}",
            "{topic}干货｜建议收藏不然找不到了",
        ],
        "need_numbers": False,
    },
    {
        "name": "提问型",
        "description": "用问题引发思考和点击",
        "templates": [
            "{topic}到底怎么做？看完这篇你就懂了",
            "为什么别人{topic}那么轻松？秘密在这里",
            "{topic}难吗？其实只要掌握这几点",
            "你真的会{topic}吗？90%的人都做错了",
        ],
        "need_numbers": False,
    },
    {
        "name": "种草安利型",
        "description": "真诚推荐，降低抵触感",
        "templates": [
            "真心推荐！这个{topic}太绝了",
            "被吹爆的{topic}，到底值不值得买",
            "{topic}天花板级别存在，用过都说好",
            "闭眼入的{topic}清单，不踩雷不后悔",
        ],
        "need_numbers": False,
    },
    {
        "name": "避坑避雷型",
        "description": "反面切入，同样吸引点击",
        "templates": [
            "{topic}避坑指南｜这些雷千万别踩",
            "血泪教训！{topic}千万别这么做",
            "{topic}的{n}个坑，我都帮你踩过了",
            "提醒大家，{topic}一定要注意这些",
        ],
        "need_numbers": True,
    },
    {
        "name": "数字对比型",
        "description": "数字+对比，视觉冲击力强",
        "templates": [
            "{topic}前vs{topic}后，变化也太大了",
            "花了{n}块钱在{topic}上，最值的居然是这个",
            "一天{n}分钟，{topic}效果堪比整容",
            "{n}天{topic}挑战，结果太意外了",
        ],
        "need_numbers": True,
    },
]

# ============================================================
# 分类相关的常用表情和关键词
# ============================================================
CATEGORY_EMOJIS = {
    "穿搭": ["👗", "👠", "👜", "💄", "✨", "🌸"],
    "美妆": ["💄", "💅", "✨", "🌸", "💆‍♀️", "🧴"],
    "美食": ["🍜", "🍰", "☕", "🍣", "😋", "🤤"],
    "旅行": ["✈️", "🏝️", "🗻", "📸", "🌅", "🎒"],
    "家居": ["🏠", "🛋️", "🛏️", "🕯️", "🌿", "✨"],
    "健身": ["💪", "🏃‍♀️", "🧘‍♀️", "🥗", "🏋️", "⚡"],
    "护肤": ["🧴", "✨", "🌸", "💆‍♀️", "💧", "🌿"],
    "数码": ["📱", "💻", "⌚", "🎧", "📷", "⚡"],
    "母婴": ["👶", "🍼", "🧸", "👩‍👧", "🎀", "💕"],
    "学习": ["📚", "✏️", "📖", "🎓", "💡", "📝"],
    "职场": ["💼", "📊", "🚀", "💡", "⏰", "📈"],
    "情感": ["💕", "💔", "💭", "🌸", "✨", "🎀"],
    "宠物": ["🐶", "🐱", "🐾", "💕", "🌸", "✨"],
    "摄影": ["📷", "🎞️", "📸", "🌅", "✨", "🎨"],
}

DEFAULT_EMOJIS = ["✨", "💡", "📝", "💕", "🌸", "🔥"]

# ============================================================
# 限流词 / 违禁词检测
# ============================================================
RESTRICTED_WORDS = [
    "最好", "最佳", "最优", "最强", "最棒", "最美", "最帅", "最高级",
    "第一", "唯一", "首个", "首选", "独家", "绝无仅有", "天下第一",
    "绝对", "绝对不会", "绝对有效", "100%", "百分之百", "完全",
    "秒杀", "爆品", "爆款", "神级", "神器", "史诗级", "殿堂级",
    "国家级", "世界级", "全球领先", "行业领先", "顶级", "极品",
    "永久", "永不", "根治", "包治", "药到病除", "无效退款",
    "立刻", "马上", "瞬间", "立即见效", "立竿见影",
    "最", "第一", "唯一", "绝对", "100%",
]


def generate_numbers(seed=None):
    """生成随机数字，用于模板填充"""
    if seed:
        random.seed(seed)
    # 常用数字
    n = random.choice([3, 5, 7, 8, 10, 12])
    n2 = random.choice([2, 3, 5])
    return {"n": str(n), "n2": str(n2)}


def get_category_emojis(category):
    """获取分类对应的表情列表"""
    return CATEGORY_EMOJIS.get(category, DEFAULT_EMOJIS)


def generate_titles(topic, category="穿搭", count=12, seed=None):
    """
    根据主题和分类生成标题候选
    返回：[{title, formula, score}]
    """
    if seed is not None:
        random.seed(seed)
    
    emojis = get_category_emojis(category)
    results = []
    
    # 从每个公式生成 1-2 个标题
    for formula in TITLE_FORMULAS:
        templates = formula["templates"]
        # 随机选择 2 个模板
        selected = random.sample(templates, min(2, len(templates)))
        
        for tmpl in selected:
            title = tmpl
            
            # 替换数字占位符
            if formula.get("need_numbers"):
                nums = generate_numbers()
                for k, v in nums.items():
                    title = title.replace("{" + k + "}", v)
            
            # 替换主题占位符
            # 对于 A/B 对比型模板，需要生成两个变体
            if "{topic}A" in title and "{topic}B" in title:
                # 简单处理：用通用替代词
                title = title.replace("{topic}A", topic + "热门款")
                title = title.replace("{topic}B", topic + "平价款")
            else:
                title = title.replace("{topic}", topic)
            
            # 随机添加开头表情（30%概率）
            if random.random() < 0.3:
                emoji = random.choice(emojis)
                title = emoji + " " + title
            
            # 随机添加结尾表情（20%概率）
            if random.random() < 0.2:
                emoji = random.choice(emojis)
                title = title + " " + emoji
            
            # 评分
            score = score_title(title, category)
            
            results.append({
                "title": title,
                "formula": formula["name"],
                "score": score,
            })
    
    # 按评分排序，取前 count 个
    results.sort(key=lambda x: x["score"]["total"], reverse=True)
    results = results[:count]
    
    return results


def score_title(title, category):
    """
    标题评分
    维度：长度、emoji使用、数字存在、情感词、限流词、可读性
    """
    score = 0
    details = {}
    
    # 1. 长度评分（满分 30）
    # 最佳长度 15-25 字
    char_count = len(re.findall(r'[\u4e00-\u9fa50-9a-zA-Z]', title))
    if 15 <= char_count <= 25:
        length_score = 30
    elif 10 <= char_count <= 30:
        length_score = 20
    elif 8 <= char_count <= 35:
        length_score = 10
    else:
        length_score = 0
    score += length_score
    details["长度"] = f"{length_score}/30（{char_count}字）"
    
    # 2. 数字加分（满分 15）
    has_number = bool(re.search(r'[0-9０-９]', title))
    if has_number:
        number_score = 15
    else:
        number_score = 5
    score += number_score
    details["数字"] = f"{number_score}/15"
    
    # 3. Emoji 加分（满分 10）
    emoji_count = len(re.findall(r'[\U00010000-\U0010ffff\u2600-\u27bf]', title))
    if emoji_count == 1:
        emoji_score = 10
    elif emoji_count == 2:
        emoji_score = 8
    elif emoji_count >= 3:
        emoji_score = 3  # 太多反减分
    else:
        emoji_score = 0
    score += emoji_score
    details["Emoji"] = f"{emoji_score}/10"
    
    # 4. 情感/互动词加分（满分 15）
    emotion_words = [
        "绝了", "真香", "yyds", "天花板", "绝绝子", "必看", "必入",
        "推荐", "安利", "种草", "收藏", "干货", "秘籍", "指南",
        "攻略", "保姆级", "手把手", "零基础", "踩坑", "避雷",
    ]
    emotion_count = sum(1 for w in emotion_words if w in title)
    if emotion_count >= 2:
        emotion_score = 15
    elif emotion_count == 1:
        emotion_score = 10
    else:
        emotion_score = 3
    score += emotion_score
    details["情感词"] = f"{emotion_score}/15（{emotion_count}个）"
    
    # 5. 悬念/钩子加分（满分 15）
    hook_patterns = [
        "原来", "竟然", "居然", "没想到", "真相", "秘密", "别再",
        "千万别", "一定要", "你不知道", "90%", "99%", "？", "?",
        "为什么", "怎么", "如何",
    ]
    hook_count = sum(1 for p in hook_patterns if p in title)
    if hook_count >= 2:
        hook_score = 15
    elif hook_count == 1:
        hook_score = 10
    else:
        hook_score = 2
    score += hook_score
    details["钩子"] = f"{hook_score}/15"
    
    # 6. 限流词扣分
    restricted_found = []
    for word in RESTRICTED_WORDS:
        if word in title:
            restricted_found.append(word)
    
    if restricted_found:
        restrict_penalty = len(restricted_found) * 10
        score -= restrict_penalty
        details["限流词"] = f"-{restrict_penalty}（{', '.join(restricted_found)}）"
    else:
        details["限流词"] = "无 ✅"
    
    # 7. 标点符号扣分（过多标点）
    punct_count = len(re.findall(r'[！!？?…~～]', title))
    if punct_count > 3:
        punct_penalty = (punct_count - 3) * 3
        score -= punct_penalty
        details["标点"] = f"-{punct_penalty}（{punct_count}个感叹/疑问）"
    else:
        details["标点"] = "正常"
    
    # 总分确保不低于 0
    total = max(0, min(100, score))
    details["总分"] = f"{total}/100"
    
    return {"total": total, "details": details, "restricted": restricted_found}


def check_restricted_words(title):
    """检查限流词"""
    found = []
    for word in RESTRICTED_WORDS:
        if word in title:
            found.append(word)
    return found


def render_report(topic, category, titles, count):
    """
    渲染 Markdown 格式的结果
    """
    lines = []
    
    lines.append("# 种草笔记标题生成")
    lines.append("")
    lines.append(f"- **主题**：{topic}")
    lines.append(f"- **分类**：{category}")
    lines.append(f"- **生成数量**：{len(titles)} 个")
    lines.append("")
    
    # 评分等级说明
    lines.append("## 评分说明")
    lines.append("")
    lines.append("| 分数段 | 等级 | 建议 |")
    lines.append("|--------|------|------|")
    lines.append("| 85-100 | 优秀 | 可直接使用 ✅ |")
    lines.append("| 70-84 | 良好 | 稍作优化即可 |")
    lines.append("| 55-69 | 一般 | 建议调整 |")
    lines.append("| <55 | 待优化 | 限流风险高 ⚠️ |")
    lines.append("")
    
    # 标题列表
    lines.append("## 候选标题（按评分排序）")
    lines.append("")
    
    for i, t in enumerate(titles, 1):
        score = t["score"]
        total = score["total"]
        
        # 等级标记
        if total >= 85:
            grade = "🌟 优秀"
        elif total >= 70:
            grade = "👍 良好"
        elif total >= 55:
            grade = "😐 一般"
        else:
            grade = "⚠️ 待优化"
        
        lines.append(f"### {i}. {t['title']}")
        lines.append("")
        lines.append(f"- **公式类型**：{t['formula']}")
        lines.append(f"- **综合评分**：{total}/100 {grade}")
        
        # 详细评分
        detail_items = []
        for k, v in score["details"].items():
            if k != "总分":
                detail_items.append(f"{k}: {v}")
        lines.append(f"- **评分明细**：{'｜'.join(detail_items)}")
        
        # 限流警告
        if score["restricted"]:
            lines.append(f"- ⚠️ **限流词警告**：{', '.join(score['restricted'])}")
            lines.append(f"- 💡 **建议**：替换或删除限流词，如使用'超赞'替代'最好'，'非常推荐'替代'第一'")
        
        lines.append("")
    
    # 使用建议
    lines.append("## 💡 使用建议")
    lines.append("")
    lines.append("1. **A/B 测试**：建议选择 2-3 个不同风格的标题同时测试，观察数据表现")
    lines.append("2. **封面配合**：标题需要和封面图形成呼应，封面传达视觉，标题传达信息")
    lines.append("3. **前 20 字最关键**：信息流中前 20 字决定点击率，把最吸引人的信息放前面")
    lines.append("4. **适度 emoji**：1-2 个 emoji 最佳，太多反而显得杂乱")
    lines.append("5. **避开限流词**：避免使用绝对化表述，用'超赞''巨好''强推'等替代")
    lines.append("")
    
    # 限流词参考
    lines.append("## ⚠️ 常见限流词参考")
    lines.append("")
    lines.append("以下词汇可能触发限流，建议替换：")
    lines.append("")
    common = ["最好", "最佳", "第一", "唯一", "绝对", "100%", "秒杀", "爆款", "神级", "顶级", "永久", "根治"]
    lines.append("、".join(f"`{w}`" for w in common))
    lines.append("")
    lines.append("替代方案：用'超赞''巨好''强推''绝绝子''天花板''真的绝了'等口语化表达")
    lines.append("")
    
    lines.append("---")
    lines.append("*由种草笔记标题生成器自动生成*")
    
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(
        description='种草笔记标题生成器 - 内置15+种标题公式，自动生成候选标题',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
内置标题公式（16种）：
  数字型    用具体数字增加可信度
  反差型    制造认知反差，激发好奇心
  悬念型    留悬念勾引读者点进来
  痛点型    精准戳中痛点，引发共鸣
  身份认同型 锁定目标人群，精准触达
  清单型    合集/清单，收藏欲拉满
  教程型    手把手教，实用价值高
  对比型    二选一/多选一，选择困难症最爱
  故事型    用故事钩子吸引人
  利益承诺型 直接说好处，给读者行动理由
  反常识型   打破固有认知，制造惊讶
  时间紧迫型 制造稀缺感和紧迫感
  提问型    用问题引发思考和点击
  种草安利型 真诚推荐，降低抵触感
  避坑避雷型 反面切入，同样吸引点击
  数字对比型 数字+对比，视觉冲击力强

示例：
  python title_generator.py --topic "夏日穿搭" --category 穿搭
  python title_generator.py --topic "护肤" --category 美妆 --count 15
  python title_generator.py --topic "减脂餐" --category 美食 --seed 42
        """
    )
    
    parser.add_argument('--topic', type=str, required=True,
                        help='标题主题/内容摘要')
    parser.add_argument('--category', type=str, default='穿搭',
                        help='内容分类（穿搭/美妆/美食/旅行/家居/健身/护肤/数码/母婴/学习/职场/情感/宠物/摄影，默认：穿搭）')
    parser.add_argument('--count', '-n', type=int, default=12,
                        help='生成标题数量（默认：12）')
    parser.add_argument('--seed', type=int, default=None,
                        help='随机种子，用于复现结果')
    parser.add_argument('--output', '-o', type=str, default=None,
                        help='输出文件路径（默认输出到 stdout）')
    parser.add_argument('--list-formulas', action='store_true',
                        help='列出所有标题公式')
    parser.add_argument('--check', type=str, default=None,
                        help='检查单个标题的评分和限流词')
    
    args = parser.parse_args()
    
    # 列出公式
    if args.list_formulas:
        print("内置标题公式：")
        for f in TITLE_FORMULAS:
            print(f"  {f['name']:<10} - {f['description']}")
        return
    
    # 单独检查标题
    if args.check:
        score = score_title(args.check, args.category)
        print(f"标题：{args.check}")
        print(f"评分：{score['total']}/100")
        print("评分明细：")
        for k, v in score['details'].items():
            print(f"  {k}: {v}")
        if score['restricted']:
            print(f"⚠️ 限流词：{', '.join(score['restricted'])}")
        else:
            print("✅ 无限流词")
        return
    
    # 生成标题
    titles = generate_titles(args.topic, args.category, args.count, args.seed)
    
    if not titles:
        print("错误：未能生成标题", file=sys.stderr)
        sys.exit(1)
    
    # 渲染报告
    report = render_report(args.topic, args.category, titles, args.count)
    
    # 输出
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(report)
        print(f"标题已生成并保存到: {args.output}")
        print(f"生成 {len(titles)} 个候选标题，最高分：{max(t['score']['total'] for t in titles)}/100")
    else:
        print(report)


if __name__ == '__main__':
    main()
