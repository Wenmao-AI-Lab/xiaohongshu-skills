#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小红书爆款笔记框架生成器（确定性、零外部依赖）。

用法:
  python3 generate.py --topic "敏感肌护肤" --persona "成分党" --goal "带货"
  echo "敏感肌护肤" | python3 generate.py --persona "成分党"

输出 Markdown 框架：选题角度 / 爆款标题(5类公式) / 正文5段 / 标签 / 封面文案。
"""
import argparse
import sys


def read_topic_from_stdin():
    if not sys.stdin.isatty():
        data = sys.stdin.read().strip()
        if data:
            return data
    return ""


def build_titles(topic, persona):
    """5 类爆款标题公式，各 2 条变体。"""
    formulas = {
        "痛点提问体": [
            f"为什么你写的{topic}总是没流量？这3个坑我全踩过",
            f"做{topic}没人看？大概率是你开头就错了",
        ],
        "数字清单体": [
            f"做{topic}的3个底层逻辑，第2个90%的人不知道",
            f"关于{topic}，我整理了5条血泪经验",
        ],
        "反差体": [
            f"别再硬写{topic}了，换个角度赞藏直接翻倍",
            f"同样是{topic}，别人爆了你不火，差的就是这一点",
        ],
        "身份认同体": [
            f"普通{persona}做{topic}，也能写出千赞笔记",
            f"没人带的{persona}，靠{topic}悄悄涨了1万粉",
        ],
        "悬念体": [
            f"我把{topic}试了30天，结果出乎意料",
            f"{topic}这件事，商家不会告诉你的真相",
        ],
    }
    out = []
    for cat, items in formulas.items():
        for t in items:
            out.append((cat, t))
    return out


def build_angles(topic):
    return [
        f"避坑向：盘点{topic}最常见的 N 个误区（收藏向，易涨赞）",
        f"对比向：{topic}的 A  vs  B，一张表说清怎么选（决策向，易转发）",
        f"蜕变向：我用{topic}解决了 XX 问题，前后对比（故事向，易共鸣）",
    ]


def build_body(topic, persona, goal):
    goal_line = {
        "带货": "结尾自然带出产品/链接，引导下单或进橱窗",
        "引流": "结尾引导关注/进群/私信，沉淀私域",
        "人设": "结尾强化人设标签，引导评论区互动",
    }.get(goal, "结尾引导关注/收藏/评论区互动")
    return [
        ("钩子(首句3秒)", f"用痛点/反差/悬念开场，例如：'{persona}最容易忽略的{topic}真相'"),
        ("痛点(共鸣)", f"描述目标用户在{topic}上的真实纠结与踩坑，让读者'是我本人'"),
        ("方法(3步/清单)", f"给可照做的{topic}步骤，每条一句人话+为什么"),
        ("证据(可信)", f"放截图/数据/前后对比，证明你说的{topic}方法真有用"),
        ("行动召唤", goal_line),
    ]


def build_tags(topic):
    industry = [f"#{topic}", f"#{topic}分享", f"#{topic}推荐", f"#{topic}日常", f"#{topic}攻略"]
    scene = [f"#新手{topic}", f"#{topic}避坑", f"#{topic}怎么选", f"#{topic}记录", f"#{topic}测评"]
    emotion = ["#干货分享", "#亲测有效", "#少走弯路", "#真实分享", "#涨粉笔记"]
    return industry + scene + emotion


def build_cover(topic, persona):
    return [
        f"{topic}｜{persona}必看的3件事",
        f"别乱做{topic}了！先看这篇",
        f"{topic}干货｜收藏不亏",
    ]


def render(topic, persona, goal):
    titles = build_titles(topic, persona)
    angles = build_angles(topic)
    body = build_body(topic, persona, goal)
    tags = build_tags(topic)
    covers = build_cover(topic, persona)

    lines = []
    lines.append(f"# 小红书爆款笔记框架 · {topic}")
    lines.append("")
    lines.append(f"- 人设：{persona} ｜ 目标：{goal}")
    lines.append("")
    lines.append("## 一、选题角度（挑 1 个切入）")
    for i, a in enumerate(angles, 1):
        lines.append(f"{i}. {a}")
    lines.append("")
    lines.append("## 二、爆款标题（5 类公式 × 2）")
    for cat, t in titles:
        lines.append(f"- **[{cat}]** {t}")
    lines.append("")
    lines.append("## 三、正文 5 段结构（填占位即成稿）")
    for i, (sec, hint) in enumerate(body, 1):
        lines.append(f"{i}. **{sec}**：{hint}")
    lines.append("")
    lines.append("## 四、标签（15 个，三类覆盖）")
    lines.append(" ".join(tags))
    lines.append("")
    lines.append("## 五、封面文案（3 选 1）")
    for i, c in enumerate(covers, 1):
        lines.append(f"{i}. {c}")
    lines.append("")
    lines.append("> 框架由 aiworkin-topic-assistant 生成；用模型把占位填成真人语气文案即可发布。")
    return "\n".join(lines)


def main():
    p = argparse.ArgumentParser(description="小红书爆款笔记框架生成器")
    p.add_argument("--topic", default="", help="核心主题/产品/关键词")
    p.add_argument("--persona", default="真实分享的普通人", help="发文人设")
    p.add_argument("--goal", default="涨粉涨赞藏", help="带货 / 引流 / 人设")
    args = p.parse_args()

    topic = args.topic or read_topic_from_stdin()
    if not topic:
        p.error("必须通过 --topic 或标准输入提供主题")

    print(render(topic, args.persona, args.goal))


if __name__ == "__main__":
    main()