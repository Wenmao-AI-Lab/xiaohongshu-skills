#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
最小 Chrome DevTools Protocol (CDP) 客户端 —— 纯 Python 标准库，零依赖。

用途：aiworkin-topic-assistant 技能包的数据获取辅助（浏览器方式）。
前置：Chrome 以调试端口启动：
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
    --remote-debugging-port=9222 --user-data-dir="$HOME/.chrome-cdp-profile"

用法:
  python3 cdp_browser.py list                          # 列出已打开页面
  python3 cdp_browser.py open "https://www.douyin.com/hot"   # 新开页面
  python3 cdp_browser.py eval <page_id> "document.title"     # 执行 JS（返回 JSON 值）
  python3 cdp_browser.py text <page_id>                      # 提取页面可见文本
  python3 cdp_browser.py scroll <page_id>                    # 滚动到底部（触发动态加载）
  python3 cdp_browser.py shot <page_id> /tmp/page.png        # 截图

不传 <page_id> 时默认操作最后打开的页面。
eval 的 JS 表达式会以 returnByValue 求值；返回 JSON 可序列化的值（对象/数组/字符串/数字）。

纪律：仅用于正常浏览节奏的页面读取（单任务 3-5 页）；不绕过验证码、不做写操作、
不抓取页面背后的 JSON 接口。详见 references/browser-cdp-guide.md。
"""
import argparse
import base64
import hashlib
import json
import os
import socket
import struct
import sys
import time
import urllib.parse
import urllib.request

CDP_HTTP = os.environ.get("CDP_HTTP", "http://127.0.0.1:9222")
WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
DEFAULT_TIMEOUT = 30


# --------------------------------------------------------------------------
# 最小 WebSocket 客户端（RFC 6455）
# --------------------------------------------------------------------------

class WSError(Exception):
    pass


class WS:
    def __init__(self, url, timeout=DEFAULT_TIMEOUT):
        parsed = urllib.parse.urlparse(url)
        host = parsed.hostname or "127.0.0.1"
        port = parsed.port or 80
        path = parsed.path or "/"
        key = base64.b64encode(os.urandom(16)).decode()
        self.sock = socket.create_connection((host, port), timeout=timeout)
        self.sock.settimeout(timeout)
        request = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}:{port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            "Sec-WebSocket-Protocol: chrome-devtools\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(request.encode())
        response = self._read_http_response()
        if " 101 " not in response.split("\r\n", 1)[0]:
            raise WSError(f"WebSocket 握手失败: {response[:200]}")
        accept = hashlib.sha1((key + WS_GUID).encode()).digest()
        expected = base64.b64encode(accept).decode().lower()
        if f"sec-websocket-accept: {expected}" not in response.lower():
            raise WSError("WebSocket 握手校验失败（Sec-WebSocket-Accept 不匹配）")

    def _read_http_response(self):
        data = b""
        while b"\r\n\r\n" not in data:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise WSError("连接中断")
            data += chunk
        return data.decode("utf-8", "replace")

    def _send_frame(self, opcode, payload):
        header = bytearray([0x80 | opcode])  # FIN + opcode
        length = len(payload)
        if length < 126:
            header.append(0x80 | length)  # MASK + len
        elif length < 65536:
            header.append(0x80 | 126)
            header += struct.pack(">H", length)
        else:
            header.append(0x80 | 127)
            header += struct.pack(">Q", length)
        mask = os.urandom(4)
        header += mask
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        self.sock.sendall(bytes(header) + masked)

    def _recv_exact(self, n):
        data = b""
        while len(data) < n:
            chunk = self.sock.recv(n - len(data))
            if not chunk:
                raise WSError("连接中断")
            data += chunk
        return data

    def _recv_frame(self):
        head = self._recv_exact(2)
        fin = head[0] & 0x80
        opcode = head[0] & 0x0F
        masked = head[1] & 0x80
        length = head[1] & 0x7F
        if length == 126:
            length = struct.unpack(">H", self._recv_exact(2))[0]
        elif length == 127:
            length = struct.unpack(">Q", self._recv_exact(8))[0]
        mask = self._recv_exact(4) if masked else None
        payload = self._recv_exact(length)
        if mask:
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        return fin, opcode, payload

    def send_text(self, text):
        self._send_frame(0x1, text.encode("utf-8"))

    def recv_text(self):
        """收帧直到收到完整的文本帧（处理 ping/pong 与分片）。"""
        chunks = []
        while True:
            fin, opcode, payload = self._recv_frame()
            if opcode == 0x9:  # ping -> pong
                self._send_frame(0xA, payload)
                continue
            if opcode == 0x8:  # close
                raise WSError("对端关闭连接")
            if opcode == 0x1:
                chunks.append(payload)
                if fin:
                    return b"".join(chunks).decode("utf-8")
            elif opcode == 0x2:
                raise WSError("收到二进制帧（预期文本帧）")

    def close(self):
        try:
            self._send_frame(0x8, b"")
        except OSError:
            pass
        self.sock.close()


# --------------------------------------------------------------------------
# CDP HTTP 端点
# --------------------------------------------------------------------------

def http_json(path, method="GET"):
    req = urllib.request.Request(
        f"{CDP_HTTP}{path}", data=b"", method=method,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as resp:
        return json.loads(resp.read().decode("utf-8"))


def list_pages():
    targets = http_json("/json/list")
    pages = [t for t in targets if t.get("type") == "page"]
    if not pages:
        print("无已打开的页面。请先运行 open 命令。", file=sys.stderr)
        sys.exit(1)
    return pages


def resolve_target(page_id):
    pages = list_pages()
    if page_id is None:
        return pages[-1]  # 默认最后打开的页面
    for t in pages:
        if t["id"] == page_id or page_id.isdigit() and t.get("index") is not None:
            if t["id"] == page_id:
                return t
    # 兼容按列表下标引用
    if page_id.isdigit() and 0 <= int(page_id) < len(pages):
        return pages[int(page_id)]
    raise SystemExit(f"未找到页面 id: {page_id}")


def new_page(url):
    quoted = urllib.parse.quote(url, safe="")
    try:
        target = http_json(f"/json/new?{quoted}", method="PUT")
    except urllib.error.HTTPError as exc:
        raise SystemExit(f"新开页面失败（HTTP {exc.code}）：{exc.reason}")
    return target


# --------------------------------------------------------------------------
# CDP 消息
# --------------------------------------------------------------------------

def send_cdp(target, method, params=None, timeout=DEFAULT_TIMEOUT):
    ws = WS(target["webSocketDebuggerUrl"], timeout=timeout)
    try:
        msg = {"id": 1, "method": method, "params": params or {}}
        ws.send_text(json.dumps(msg))
        while True:
            data = json.loads(ws.recv_text())
            if data.get("id") == 1:
                return data
    finally:
        ws.close()


def eval_js(target, expression, timeout=DEFAULT_TIMEOUT):
    result = send_cdp(
        target, "Runtime.evaluate",
        {"expression": expression, "returnByValue": True, "awaitPromise": True},
        timeout=timeout,
    )
    error = result.get("error")
    if error:
        raise SystemExit(f"CDP 错误: {error.get('message', error)}")
    r = result.get("result", {})
    if r.get("exceptionDetails"):
        detail = r["exceptionDetails"]
        text = detail.get("text", "JS 异常")
        desc = (detail.get("exception") or {}).get("description", "")
        raise SystemExit(f"{text}: {desc[:300]}")
    return r.get("result", {}).get("value")


# --------------------------------------------------------------------------
# 命令实现
# --------------------------------------------------------------------------

def cmd_list(_args):
    for i, t in enumerate(list_pages()):
        print(f"[{i}] {t['id']}  {t.get('title', '')[:40]}  {t.get('url', '')[:80]}")


def cmd_open(args):
    target = new_page(args.url)
    print(target.get("id", ""))
    print(target.get("url", ""))
    # 等待页面开始加载
    time.sleep(1.0)


def cmd_eval(args):
    target = resolve_target(args.page_id)
    value = eval_js(target, args.expression)
    print(json.dumps(value, ensure_ascii=False, indent=2))


def cmd_text(args):
    target = resolve_target(args.page_id)
    text = eval_js(target, "document.body ? document.body.innerText : ''")
    print(text or "")


def cmd_scroll(args):
    target = resolve_target(args.page_id)
    before = eval_js(target, "document.body ? document.body.scrollHeight : 0")
    eval_js(target, "window.scrollTo(0, document.body.scrollHeight)")
    time.sleep(1.5)
    after = eval_js(target, "document.body ? document.body.scrollHeight : 0")
    print(json.dumps({"before": before, "after": after, "reached_bottom": after == before},
                     ensure_ascii=False))


def cmd_shot(args):
    target = resolve_target(args.page_id)
    data = send_cdp(target, "Page.captureScreenshot", {"format": "png"})
    r = data.get("result", {})
    if not r.get("data"):
        raise SystemExit("截图失败：无返回数据")
    with open(args.path, "wb") as f:
        f.write(base64.b64decode(r["data"]))
    print(f"截图已保存: {args.path}")


PROBE_JS = """(() => {
  const bodyText = document.body ? document.body.innerText : '';
  const head = bodyText.slice(0, 2000);
  return {
    url: location.href,
    title: document.title,
    readyState: document.readyState,
    textLength: bodyText.length,
    linkCount: document.querySelectorAll('a').length,
    captcha: /验证码|安全验证|拖动滑块|滑动验证|captcha|verify/i.test(head),
    loginRequired: /请先登录|扫码登录|登录后查看|立即登录/i.test(head),
    emptyPage: bodyText.trim().length < 50,
    sample: head.slice(0, 150)
  };
})()"""


def cmd_probe(args):
    """自愈诊断：探测页面状态，辅助定位失败根因（healing-ledger.md 故障分类 A-F）"""
    target = resolve_target(args.page_id)
    value = eval_js(target, PROBE_JS)
    print(json.dumps(value, ensure_ascii=False, indent=2))


# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="最小 CDP 浏览器控制客户端（零依赖）")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("list", help="列出已打开页面")
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("open", help="新开页面")
    p.add_argument("url", help="要打开的 URL")
    p.set_defaults(func=cmd_open)

    p = sub.add_parser("eval", help="在页面执行 JS 并返回 JSON 值")
    p.add_argument("expression", help="JS 表达式（returnByValue 求值）")
    p.add_argument("page_id", nargs="?", default=None, help="页面 id（默认最后打开的页面）")
    p.set_defaults(func=cmd_eval)

    p = sub.add_parser("text", help="提取页面可见文本 body.innerText")
    p.add_argument("page_id", nargs="?", default=None)
    p.set_defaults(func=cmd_text)

    p = sub.add_parser("scroll", help="滚动到底部（触发动态加载），打印前后高度")
    p.add_argument("page_id", nargs="?", default=None)
    p.set_defaults(func=cmd_scroll)

    p = sub.add_parser("shot", help="截图保存为 PNG")
    p.add_argument("path", help="输出文件路径")
    p.add_argument("page_id", nargs="?", default=None)
    p.set_defaults(func=cmd_shot)

    p = sub.add_parser("probe", help="自愈诊断：探测页面状态（验证码/登录态/空白页等）")
    p.add_argument("page_id", nargs="?", default=None)
    p.set_defaults(func=cmd_probe)

    args = parser.parse_args()
    try:
        args.func(args)
    except (WSError, OSError) as exc:
        print(f"CDP 连接失败：{exc}\n"
              "请确认 Chrome 已用 --remote-debugging-port=9222 启动，且 CDP_HTTP 端口正确。",
              file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()