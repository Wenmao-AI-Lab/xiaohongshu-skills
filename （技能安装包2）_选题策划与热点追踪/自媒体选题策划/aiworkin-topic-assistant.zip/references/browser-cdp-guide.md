# 浏览器/CDP 操作手册（数据获取核心）

> 本技能包**所有数据一律通过浏览器打开平台网页实时获取**，不依赖任何外部 MCP / 付费 API / API Key。
> 本文件说明三种执行方式、平台页面对照、操作步骤与纪律。

## 一、为什么用浏览器

| 对比项 | 浏览器方式（本包） | 外部 API 方式（弃用） |
|---|---|---|
| 密钥 | 无需任何 Key | 需要各家付费 Key |
| 计费 | 零成本 | 按次计费 |
| 数据时效 | 页面实时 | 依赖各家更新节奏 |
| 可追溯 | 有页面/截图可复核 | 黑盒返回 |
| 风险 | 登录态/风控需注意 | 额度/余额风险 |

## 二、三种执行方式（按可用性优先）

### 方式 1：宿主浏览器工具（推荐）

宿主环境自带的浏览器/CDP 能力（如 Qoder 的 Browser 工具、浏览器预览、CDP 集成等）：
1. 用浏览器工具打开目标 URL。
2. 等待渲染（动态页面等 2-3 秒），需要时滚动加载更多。
3. 从页面 DOM 读取数据（标题/数据/链接），必要时截图留证。
4. 需要搜索时，直接在页面搜索框输入关键词执行搜索（或直接拼 URL）。

### 方式 2：CDP 直连 Chrome

以调试端口启动 Chrome，用 CDP 协议控制：

```bash
# macOS（使用独立用户目录，避免影响日常浏览器）
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --remote-debugging-port=9222 \
  --user-data-dir="$HOME/.chrome-cdp-profile" \
  --no-first-run --no-default-browser-check

# Windows
start chrome --remote-debugging-port=9222 --user-data-dir="%USERPROFILE%\.chrome-cdp-profile"

# Linux
google-chrome --remote-debugging-port=9222 --user-data-dir="$HOME/.chrome-cdp-profile"
```

- 验证：`curl http://127.0.0.1:9222/json/version`
- 列出页面：`curl http://127.0.0.1:9222/json`
- **登录态**：先用该调试实例手动登录目标平台（小红书等），登录态会保存在 `--user-data-dir` 目录，之后所有抓取会话复用该登录态。

### 方式 3：辅助脚本 `scripts/cdp_browser.py`

纯 Python 标准库实现的最小 CDP 客户端（零依赖）：

```bash
# 列出所有已打开页面
python3 scripts/cdp_browser.py list

# 新开页面
python3 scripts/cdp_browser.py open "https://www.douyin.com/hot"

# 在页面执行 JS 并返回结果
python3 scripts/cdp_browser.py eval <page_id> "document.title"

# 提取页面可见文本（body.innerText）
python3 scripts/cdp_browser.py text <page_id>

# 滚动到底部（触发动态加载）
python3 scripts/cdp_browser.py scroll <page_id>

# 截图
python3 scripts/cdp_browser.py shot <page_id> /tmp/page.png
```

- 不传 `<page_id>` 时默认操作**最后打开的页面**。
- `eval` 的 JS 返回 JSON 可序列化值（对象/数组/字符串/数字），适合提取结构化列表数据。

**通用 JS 提取示例**（在小红书搜索页提取笔记列表）：
```js
Array.from(document.querySelectorAll('section.note-item')).map(n => ({
  title: n.querySelector('.title')?.innerText || '',
  author: n.querySelector('.author')?.innerText || '',
  like: n.querySelector('.like-wrapper .count')?.innerText || ''
}))
```

> 页面结构会随平台改版变化：选择器失效时，改用 `text` 命令提取全页文本，再人工/LLM 整理成结构化数据。**不要为了适配页面反复高频刷新**。

## 三、平台页面对照表

| 平台 | 能力 | URL 模板 | 登录态 | 备注 |
|---|---|---|---|---|
| 抖音 | 实时热榜/上升榜 | `https://www.douyin.com/hot` | 无需 | 有总榜/上升榜切换、分类筛选 |
| 抖音 | 关键词搜索 | `https://www.douyin.com/search/{关键词}` | 无需 | 支持排序/时间/时长/内容类型筛选 |
| 小红书 | 关键词搜索 | `https://www.xiaohongshu.com/search_result?keyword={关键词}` | **需要** | 有综合/最热/最新排序 |
| 小红书 | 笔记详情 | `https://www.xiaohongshu.com/explore/{笔记ID}` | 需要 | 正文/完整互动数据/封面 |
| 公众号 | 文章搜索 | `https://weixin.sogou.com/weixin?type=2&query={关键词}` | 可能弹验证码 | 标题/公众号/时间/部分阅读量 |
| 头条 | 热榜 | `https://www.toutiao.com/hot-event/hot-board/` | 无需 | 实时热榜 |
| 知乎 | 热榜 | `https://www.zhihu.com/hot` | 无需 | 深度讨论话题 |
| 微博 | 热搜榜 | `https://s.weibo.com/top/summary` | 无需 | 实时热搜 |

**公众号注意**：微信"搜一搜"无公开网页版；搜狗微信是常用替代。搜狗微信触发验证码时：降低查询频率、换时段重试、或改从知乎/微博/头条交叉验证该话题热度并如实说明数据来源。

**小红书注意**：搜索需登录态。用 CDP 调试实例预先登录（见方式 2）；登录态不可用时，如实告知用户"需要已登录的浏览器会话"，不要硬抓（会触发风控）。

## 四、标准操作流程（SOP）

1. **定页面**：按需求查上面页面对照表，确定 URL。
2. **开页面**：浏览器/脚本打开 URL，等渲染（动态页 2-3 秒）。
3. **筛选与搜索**：需要筛选时操作页面控件（排序/时间/类型）；需要搜索时输入关键词执行。
4. **读取数据**：从 DOM 读取条目（标题/作者/数据/链接），滚动加载 2-3 屏拿足样本（15-20 条）。
5. **深挖**：对关键条目点进详情页读正文/评论区（找痛点与争议）。
6. **截图留证**：关键榜单/结果页截图，交付时附上增强可信度。
7. **记录时间**：所有数据标注**读取时间**（`YYYY-MM-DD HH:MM`）。
8. **整理输出**：按各子技能输出模板整理成 Markdown 报告。

## 五、数据记录格式

每条抓取数据保留：`来源平台 + 页面类型 + 读取时间 + 条目（标题/作者/数据/链接）`。

示例：

## 七、故障自愈流程（方法失败时的标准动作）

CDP 方法失败时（字段读不到 / 页面异常 / 连接失败），按以下流程自愈，并**沉淀经验、必要时升级技能包**。完整规则见 `references/healing-ledger.md`（自愈经验档案）。

### 自愈三步

1. **probe 诊断**：`python3 scripts/cdp_browser.py probe <page_id>`，看 `url / textLength / captcha / loginRequired / emptyPage`。
2. **定位根因**：
   - 连不上 → F 连接问题：重启 Chrome 调试实例、确认 9222 端口；若报"WebSocket 握手校验失败"，确认脚本为最新版（Chrome 151+ 要求 `chrome-devtools` 子协议头，已内置，勿用旧版脚本）
   - `captcha=true` → D 风控：**立即停止**，换时段/换方式
   - `loginRequired=true` → C 登录失效：CDP 实例重新登录
   - url 404/跳转 → B 入口变化：找新入口，更新下方页面对照表
   - 文本过短/空白 → E 渲染未完成：先 scroll + 等待重试一次
   - 页面正常但字段读不到 → A 结构变化：用 `text` 全文提取 + LLM 整理
3. **收尾**：在 `healing-ledger.md` 追加一条经验记录；持久变化（≥2 次复现/整体改版）按该文件的升级规则升级技能包（更新对照表/子技能 SOP → 版本号 +0.0.1 → 登记升级日志）。

> 自愈红线：不绕过验证码/风控、不抓页面背后 JSON 接口、不把一次性故障当永久改版、升级只改技能包内文件。

## 六、纪律与红线（必须遵守）

- ❌ **不调用任何外部 MCP / 付费 API / 第三方数据接口**（红狐、SocialDataX、AI Skills、Beatra 等一律不用）。
- ❌ **不绕过验证码/风控**：出现验证码即停止，换时段或换方式，绝不破解。
- ❌ **不做写操作**：不点赞、不评论、不关注、不收藏、不发布（登录态仅用于浏览）。
- ❌ **不批量高频抓取**：单次任务 3-5 页内，保持正常浏览节奏，不写爬虫循环。
- ❌ **不抓取页面外的接口请求**：只用页面可见内容，不解析/调用页面背后的 JSON 接口（那是平台内部 API，属于外部 API 范畴）。
- ✅ 抓取失败/数据不足时：如实说明，基于已有数据工作，或请求用户提供材料（截图/链接/口头信息）。
- ✅ 登录态中不记录、不导出任何用户账号凭据。
- ✅ **失败即自愈**：任何一步失败都走上方第七节自愈流程，禁止静默跳过数据或换外部 API 硬取。
- ✅ **经验必沉淀**：每次自愈后在 `references/healing-ledger.md` 记录，供下次复用。