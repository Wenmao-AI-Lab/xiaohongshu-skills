# -*- coding: utf-8 -*-
"""图片去水印：按矩形区域做修复式擦除（OpenCV inpaint）。

依赖：pip install opencv-python numpy

用法：
  # 单张图，单个水印区域（x y w h，左上角为原点）
  python del_watermark.py in.jpg out.jpg --rect 100,800,600,120

  # 多个区域
  python del_watermark.py in.jpg out.jpg --rect 100,800,600,120 --rect 20,20,180,60

  # 整目录批量：输出到 out_dir，文件名保持不变
  python del_watermark.py ./带水印图 ./去水印图 --rect 100,800,600,120

  # 用百分比定位（右下角 80%-95% 高度区间整条）：--rect-pct 0,0.80,1,0.12
参数：
  --rect      x,y,w,h  像素坐标，可重复
  --rect-pct  x,y,w,h  0-1 相对坐标，可重复（与 --rect 可混用）
  --radius    修复半径，默认 5；水印越大可调到 7-9
  --method    telea(默认) 或 ns
  --suffix    批量模式输出文件名后缀，默认空（原名覆盖到输出目录）
"""
import argparse
import os
import sys

try:
    import cv2
    import numpy as np
except ImportError:
    sys.exit("缺少依赖，请先执行：pip install opencv-python numpy")

EXTS = (".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff")


def parse_rects(args):
    rects = []
    for r in args.rect or []:
        x, y, w, h = (int(float(v)) for v in r.split(","))
        rects.append(("px", x, y, w, h))
    for r in args.rect_pct or []:
        x, y, w, h = (float(v) for v in r.split(","))
        rects.append(("pct", x, y, w, h))
    return rects


def build_mask(shape, rects):
    h, w = shape[:2]
    mask = np.zeros((h, w), np.uint8)
    for kind, x, y, rw, rh in rects:
        if kind == "pct":
            x, y, rw, rh = int(x * w), int(y * h), int(rw * w), int(rh * h)
        x0, y0 = max(0, int(x)), max(0, int(y))
        x1, y1 = min(w, int(x + rw)), min(h, int(y + rh))
        if x1 > x0 and y1 > y0:
            mask[y0:y1, x0:x1] = 255
    return mask


def process(src, dst, rects, radius, method):
    img = cv2.imread(src, cv2.IMREAD_COLOR)
    if img is None:
        return False, "无法读取图片"
    mask = build_mask(img.shape, rects)
    if mask.sum() == 0:
        return False, "掩膜为空（矩形超出图片范围）"
    flag = cv2.INPAINT_NS if method == "ns" else cv2.INPAINT_TELEA
    out = cv2.inpaint(img, mask, radius, flag)
    os.makedirs(os.path.dirname(os.path.abspath(dst)), exist_ok=True)
    cv2.imwrite(dst, out)
    return True, "ok"


def main():
    ap = argparse.ArgumentParser(description="图片去水印（OpenCV 修复式擦除）")
    ap.add_argument("src", help="输入图片，或输入目录")
    ap.add_argument("dst", help="输出图片，或输出目录")
    ap.add_argument("--rect", action="append", help="x,y,w,h 像素坐标，可重复")
    ap.add_argument("--rect-pct", action="append", help="x,y,w,h 相对坐标 0-1，可重复")
    ap.add_argument("--radius", type=int, default=5)
    ap.add_argument("--method", choices=["telea", "ns"], default="telea")
    ap.add_argument("--suffix", default="")
    a = ap.parse_args()

    rects = parse_rects(a)
    if not rects:
        sys.exit("请至少提供一个 --rect 或 --rect-pct")

    if os.path.isdir(a.src):
        files = [f for f in sorted(os.listdir(a.src)) if f.lower().endswith(EXTS)]
        if not files:
            sys.exit("目录内没有图片")
        ok = fail = 0
        for f in files:
            stem, ext = os.path.splitext(f)
            out = os.path.join(a.dst, stem + a.suffix + ext)
            good, msg = process(os.path.join(a.src, f), out, rects, a.radius, a.method)
            print(("  ✔ " if good else "  ✘ ") + f + ("" if good else "  " + msg))
            ok, fail = (ok + 1, fail) if good else (ok, fail + 1)
        print("完成：成功 %d 张，失败 %d 张" % (ok, fail))
    else:
        good, msg = process(a.src, a.dst, rects, a.radius, a.method)
        print(("✔ " + a.dst) if good else ("✘ " + msg))
        sys.exit(0 if good else 1)


if __name__ == "__main__":
    main()
