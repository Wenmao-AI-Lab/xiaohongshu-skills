---
name: xiaohongshu-extract
description: "从小红书分享链接或发现页链接中提取笔记元数据：解析页面 window.__INITIAL_STATE__，返回笔记详情。当需要从公开的小红书链接获取笔记正文、笔记元数据、视频信息或互动数据时使用。"
displayName: 小红书内容元数据智能提取
version: 1.0.0
---

# Xiaohongshu Extract

## Overview

Extract note metadata (title, desc, type, time, user, engagement, tags, video stream info) from an XHS share or discovery URL using the bundled script.

## Quick Start

Run the extractor and print JSON to stdout:

```bash
python scripts/xiaohongshu_extract.py "<xhs_url>" --pretty
```

Write JSON to a file:

```bash
python scripts/xiaohongshu_extract.py "<xhs_url>" --output /tmp/xhs_note.json
```

Output only the flattened record:

```bash
python scripts/xiaohongshu_extract.py "<xhs_url>" --flat-only --pretty
```

Write only the flattened record to a file:

```bash
python scripts/xiaohongshu_extract.py "<xhs_url>" --flat-only --output /tmp/xhs_flat.json
```

Emit errors as JSON:

```bash
python scripts/xiaohongshu_extract.py "<xhs_url>" --error-json
```

Emit errors as JSON to a file:

```bash
python scripts/xiaohongshu_extract.py "<xhs_url>" --error-json --output /tmp/xhs_error.json
```

## Workflow

1. Run `scripts/xiaohongshu_extract.py` with the user-provided URL.
2. If the script fails to find `window.__INITIAL_STATE__`, ask the user for a direct discovery URL.
3. Use the JSON output to summarize note metadata or to feed downstream analysis.

## Output Notes

The script returns a JSON object with:

- `note_id`, `title`, `desc`, `type`, `time`, `ip_location`
- `user` (nickname, user_id, avatar)
- `interact` (liked/collected/comment/share counts, plus normalized *_num values)
- `tags`
- `video` (video_id, duration, width, height, fps, size, stream_url)
- `field_mapping` (nested-to-flat field name map)
- `flat` (flattened record with normalized counts and ISO timestamp)

If the stream list is empty, `video` fields may be null or empty.

If `--flat-only` is set, only `flat` is printed. If `--error-json` is set, errors are emitted as JSON and may include `final_url` and `status_code` when available.

## Resources

### scripts/

- `scripts/xiaohongshu_extract.py` extracts note metadata from XHS share/discovery URLs.

---

> **本技能包由「淘宝店：AI灵匣」整理优化** —— 全套 AI 工作流技能包供应商
